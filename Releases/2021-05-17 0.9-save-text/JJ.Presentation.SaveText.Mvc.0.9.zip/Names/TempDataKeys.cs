﻿using JJ.Framework.Exceptions;

namespace JJ.Presentation.SaveText.Mvc.Names
{
	internal abstract class TempDataKeys
	{
	    public void ViewModel() => throw new NameOfOnlyException();
	}
}