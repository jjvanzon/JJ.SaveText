﻿using System.Web.Mvc;

namespace JJ.Presentation.SaveText.Mvc
{
	public class FilterConfig
	{
		public static void RegisterGlobalFilters(GlobalFilterCollection filters) => filters.Add(new HandleErrorAttribute());
	}
}