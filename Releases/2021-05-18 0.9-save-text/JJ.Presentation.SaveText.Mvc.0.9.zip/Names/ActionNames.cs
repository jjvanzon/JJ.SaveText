﻿using JJ.Framework.Exceptions;

namespace JJ.Presentation.SaveText.Mvc.Names
{
	public abstract class ActionNames
	{
	    public static void Index() => throw new NameOfOnlyException();
	}
}