﻿using System.Collections.Generic;
using NUnit.Framework;
using NHibernate.Linq;
using System.Linq;

namespace NHibernate.Test.NHSpecificTest.NH3083
{
	[TestFixture]
	public class Fixture : BugTestCase
	{
		protected override void Configure(Cfg.Configuration configuration)
		{
			configuration.SetProperty(Cfg.Environment.ShowSql, "true");
			base.Configure(configuration);
		}

		public override string BugNumber
		{
			get
			{
				return "NH3083";
			}
		}

		//protected override HbmMapping GetMappings()
		//{
		//    var mapper = new ModelMapper();
		//    mapper.Class<Model>(rc => rc.ComponentAsId(x => x.Id, m =>
		//                                                            {
		//                                                                m.Property(k => k.Part1);
		//                                                                m.Property(k => k.Part2);
		//                                                            }));

		//    //mapper.UnionSubclass<Cat>(x => x.Property(p => p.NumberOfLegs));

		//    return mapper.CompileMappingForAllExplicitlyAddedEntities();
		//}

		protected override void OnSetUp()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				s.Save(new Model { Id = new CompositeKey("alpha", "bar1") });
				s.Save(new Model { Id = new CompositeKey("alpha", "bar2") });
				s.Save(new Model { Id = new CompositeKey("beta", "bar1") });
				tx.Commit();
			}
		}


		[Test]
		public void CanGetByComponentId()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var key = new CompositeKey("fo1", "fo2");

				var model = s.Get<Model>(key);
				Assert.That(model, Is.Not.Null);

				tx.Commit();
			}
		}


		[Test]
		public void CanQueryComponentIdWithInClause()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var keys = new List<CompositeKey>
					{
						new CompositeKey("alpha", "bar2"),
						new CompositeKey("beta", "bar1"),
					};

				var models = s.QueryOver<Model>()
					.WhereRestrictionOn(m => m.Id).IsInG(keys)
					.List();

				Assert.That(models, Has.Count.EqualTo(2));

				tx.Commit();
			}
		}


		[Test]
		public void CanQueryComponentIdWithInClauseHql()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var keys = new List<CompositeKey>
					{
						new CompositeKey("alpha", "bar2"),
						new CompositeKey("beta", "bar1"),
					};

				var models = s.CreateQuery("from Model m where m.Id in (:keys)")
					.SetParameterList("keys", keys)
					.List<Model>();

				Assert.That(models, Has.Count.EqualTo(2));

				tx.Commit();
			}
		}


		[Test]
		public void CanQueryComponentIdWithInClauseLinq()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var keys = new List<CompositeKey>
					{
						new CompositeKey("alpha", "bar2"),
						new CompositeKey("beta", "bar1"),
					};

				var models = s.Query<Model>()
					.Where(m => keys.Contains(m.Id))
					.ToList();

				Assert.That(models, Has.Count.EqualTo(2));

				tx.Commit();
			}
		}

		protected override void OnTearDown()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				foreach (var m in s.QueryOver<Model>().List())
					s.Delete(m);

				tx.Commit();
			}
		}
	}
}