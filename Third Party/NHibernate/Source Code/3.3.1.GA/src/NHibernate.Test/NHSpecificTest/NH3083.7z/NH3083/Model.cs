﻿using System;

namespace NHibernate.Test.NHSpecificTest.NH3083
{
	public class CompositeKey : IEquatable<CompositeKey>
	{
		public string Part1 { get; protected set; }
		public string Part2 { get; protected set; }

		public CompositeKey()
		{
		}

		public CompositeKey(string part1, string part2)
		{
			Part1 = part1;
			Part2 = part2;
		}

		public bool Equals(CompositeKey other)
		{
			if (ReferenceEquals(null, other))
				return false;
			if (ReferenceEquals(this, other))
				return true;
			return Equals(other.Part1, Part1) && Equals(other.Part2, Part2);
		}

		public override bool Equals(object obj)
		{
			if (ReferenceEquals(null, obj))
				return false;
			if (ReferenceEquals(this, obj))
				return true;
			if (obj.GetType() != typeof(CompositeKey))
				return false;
			return Equals((CompositeKey)obj);
		}

		public override int GetHashCode()
		{
			unchecked
			{
				return ((Part1 != null ? Part1.GetHashCode() : 0) * 397) ^ (Part2 != null ? Part2.GetHashCode() : 0);
			}
		}

		public static bool operator ==(CompositeKey left, CompositeKey right)
		{
			return Equals(left, right);
		}

		public static bool operator !=(CompositeKey left, CompositeKey right)
		{
			return !Equals(left, right);
		}
	}


	public class Model
	{
		public virtual CompositeKey Id { get; set; }
	}
}
