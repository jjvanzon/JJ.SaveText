﻿using System.Collections.Generic;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Mapping.ByCode;
using NUnit.Framework;

namespace NHibernate.Test.NHSpecificTest.NH3083
{
	[TestFixture]
	public class Fixture : TestCaseMappingByCode
	{
		protected override void Configure(Cfg.Configuration configuration)
		{
			configuration.SetProperty(Cfg.Environment.ShowSql, "true");
			base.Configure(configuration);
		}

		protected override HbmMapping GetMappings()
		{
			var mapper = new ModelMapper();
			mapper.Class<Model>(rc => rc.ComponentAsId(x => x.Id, m =>
																	{
																		m.Property(k => k.Part1);
																		m.Property(k => k.Part2);
																	}));

			//mapper.UnionSubclass<Cat>(x => x.Property(p => p.NumberOfLegs));

			return mapper.CompileMappingForAllExplicitlyAddedEntities();
		}

		protected override void OnSetUp()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var m = new Model
					{
						Id = new CompositeKey("fo1", "fo2"),
					};
				s.Save(m);
				tx.Commit();
			}
		}


		[Test]
		public void CanGetByComponentId()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var key = new CompositeKey("fo1", "fo2");

				var model = s.Get<Model>(key);
				Assert.That(model, Is.Not.Null);

				tx.Commit();
			}
		}


		[Test]
		public void CanQueryComponentIdWithInClause()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				var keys = new List<CompositeKey>
					{
						new CompositeKey("fo1","fo2"),
						new CompositeKey("fo2.1","fo2.2"),
					};

				var models = s.QueryOver<Model>()
					.WhereRestrictionOn(m => m.Id).IsInG(keys)
					.List();

				Assert.That(models, Has.Count.EqualTo(1));

				tx.Commit();
			}
		}


		protected override void OnTearDown()
		{
			using (var s = OpenSession())
			using (var tx = s.BeginTransaction())
			{
				foreach (var m in s.QueryOver<Model>().List())
					s.Delete(m);

				tx.Commit();
			}
		}
	}
}